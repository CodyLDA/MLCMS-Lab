The files have to be placed in the appropriate package folders.
You can find which package they belong to in the first line of each file.